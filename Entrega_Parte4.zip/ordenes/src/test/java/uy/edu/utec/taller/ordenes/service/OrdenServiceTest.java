package uy.edu.utec.taller.ordenes.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uy.edu.utec.taller.ordenes.client.ProductoClient;
import uy.edu.utec.taller.ordenes.client.dto.ProductoResponse;
import uy.edu.utec.taller.ordenes.dto.LineaOrdenCreateDTO;
import uy.edu.utec.taller.ordenes.dto.OrdenCreadaDTO;
import uy.edu.utec.taller.ordenes.dto.OrdenCreateDTO;
import uy.edu.utec.taller.ordenes.dto.OrdenDTO;
import uy.edu.utec.taller.ordenes.dto.OrdenDetalleDTO;
import uy.edu.utec.taller.ordenes.exception.EstadoNoPermitidoException;
import uy.edu.utec.taller.ordenes.exception.OrdenNoEncontradaException;
import uy.edu.utec.taller.ordenes.exception.ProductosInexistentesException;
import uy.edu.utec.taller.ordenes.exception.StockInsuficienteException;
import uy.edu.utec.taller.ordenes.exception.TransicionEstadoInvalidaException;
import uy.edu.utec.taller.ordenes.model.EstadoOrden;
import uy.edu.utec.taller.ordenes.model.LineaOrden;
import uy.edu.utec.taller.ordenes.model.Orden;
import uy.edu.utec.taller.ordenes.repository.OrdenRepository;

@ExtendWith(MockitoExtension.class)
class OrdenServiceTest {

    @Mock
    private OrdenRepository ordenRepository;

    @Mock
    private ProductoClient productoClient;

    @InjectMocks
    private OrdenService ordenService;

    @Test
    @DisplayName("listarOrdenes debe retornar lista mapeada de DTOs")
    void testListarOrdenes() {
        Orden orden = Orden.builder()
                .id(1001L)
                .email("cliente@email.com")
                .direccionEnvio("Av. Italia 3333, Maldonado")
                .telefono("+59899111222")
                .estado(EstadoOrden.Created)
                .fechaCreacion(OffsetDateTime.parse("2026-06-21T14:30:00-03:00"))
                .productos(List.of(
                        LineaOrden.builder().productoId(1L).cantidad(2).build(),
                        LineaOrden.builder().productoId(2L).cantidad(5).build()))
                .build();

        when(ordenRepository.findAll()).thenReturn(List.of(orden));

        List<OrdenDTO> resultado = ordenService.listarOrdenes();

        assertThat(resultado).hasSize(1);
        OrdenDTO dto = resultado.getFirst();
        assertThat(dto.getId()).isEqualTo(1001L);
        assertThat(dto.getEmail()).isEqualTo("cliente@email.com");
        assertThat(dto.getEstado()).isEqualTo(EstadoOrden.Created);
        assertThat(dto.getProductos()).hasSize(2);
        assertThat(dto.getProductos().getFirst().getProductoId()).isEqualTo(1L);
        assertThat(dto.getProductos().getFirst().getCantidad()).isEqualTo(2);
    }

    @Test
    @DisplayName("listarOrdenesPorEstado consulta el repositorio por estado y mapea a DTOs")
    void testListarOrdenesPorEstado() {
        when(ordenRepository.findByEstadoOrderByIdAsc(EstadoOrden.Created)).thenReturn(List.of(ordenEn(EstadoOrden.Created)));

        List<OrdenDTO> resultado = ordenService.listarOrdenesPorEstado(EstadoOrden.Created);

        assertThat(resultado).hasSize(1);
        assertThat(resultado.getFirst().getEstado()).isEqualTo(EstadoOrden.Created);
    }

    @Test
    @DisplayName("listarOrdenes retorna lista vacía si no hay órdenes")
    void testListarOrdenesVacio() {
        when(ordenRepository.findAll()).thenReturn(List.of());

        List<OrdenDTO> resultado = ordenService.listarOrdenes();

        assertThat(resultado).isEmpty();
    }

    @Test
    @DisplayName("obtenerOrden devuelve el DTO cuando la orden existe")
    void testObtenerOrdenExistente() {
        Orden orden = Orden.builder()
                .id(1001L)
                .email("cliente@email.com")
                .direccionEnvio("Av. Italia 3333, Maldonado")
                .telefono("+59899111222")
                .estado(EstadoOrden.Created)
                .fechaCreacion(OffsetDateTime.parse("2026-06-21T14:30:00-03:00"))
                .productos(List.of(
                        LineaOrden.builder().productoId(1L).cantidad(2).build(),
                        LineaOrden.builder().productoId(2L).cantidad(5).build()))
                .build();

        when(ordenRepository.findById(1001L)).thenReturn(Optional.of(orden));

        OrdenDTO dto = ordenService.obtenerOrden(1001L);

        assertThat(dto.getId()).isEqualTo(1001L);
        assertThat(dto.getEmail()).isEqualTo("cliente@email.com");
        assertThat(dto.getEstado()).isEqualTo(EstadoOrden.Created);
        assertThat(dto.getProductos()).hasSize(2);
    }

    @Test
    @DisplayName("obtenerOrden lanza OrdenNoEncontradaException cuando no existe")
    void testObtenerOrdenInexistente() {
        when(ordenRepository.findById(9999L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> ordenService.obtenerOrden(9999L))
                .isInstanceOf(OrdenNoEncontradaException.class)
                .hasMessage("No existe la orden con id 9999");
    }

    @Test
    @DisplayName("obtenerDetalleOrden compone cada línea con el producto, su subtotal y el total")
    void testObtenerDetalleOrden() {
        Orden orden = Orden.builder()
                .id(1001L)
                .email("cliente@email.com")
                .direccionEnvio("Av. Italia 3333, Maldonado")
                .telefono("+59899111222")
                .estado(EstadoOrden.Created)
                .fechaCreacion(OffsetDateTime.parse("2026-06-21T14:30:00-03:00"))
                .productos(List.of(
                        LineaOrden.builder().productoId(1L).cantidad(2).build(),
                        LineaOrden.builder().productoId(2L).cantidad(5).build()))
                .build();

        when(ordenRepository.findById(1001L)).thenReturn(Optional.of(orden));
        when(productoClient.obtenerProducto(1L)).thenReturn(Optional.of(ProductoResponse.builder()
                .id(1L).nombre("Notebook Lenovo ThinkPad").precioUnitario(1250.50).stock(13).build()));
        when(productoClient.obtenerProducto(2L)).thenReturn(Optional.of(ProductoResponse.builder()
                .id(2L).nombre("Mouse Logitech MX Master 3").precioUnitario(99.90).stock(35).build()));

        OrdenDetalleDTO detalle = ordenService.obtenerDetalleOrden(1001L);

        assertThat(detalle.getId()).isEqualTo(1001L);
        assertThat(detalle.getProductos()).hasSize(2);
        assertThat(detalle.getProductos().get(0).getCantidad()).isEqualTo(2);
        assertThat(detalle.getProductos().get(0).getSubtotal()).isEqualTo(2501.00);
        assertThat(detalle.getProductos().get(0).getProducto().getNombre()).isEqualTo("Notebook Lenovo ThinkPad");
        assertThat(detalle.getProductos().get(1).getSubtotal()).isEqualTo(499.50);
        assertThat(detalle.getTotal()).isEqualTo(3000.50);
    }

    @Test
    @DisplayName("obtenerDetalleOrden lanza OrdenNoEncontradaException cuando no existe")
    void testObtenerDetalleOrdenInexistente() {
        when(ordenRepository.findById(9999L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> ordenService.obtenerDetalleOrden(9999L))
                .isInstanceOf(OrdenNoEncontradaException.class)
                .hasMessage("No existe la orden con id 9999");
    }

    private static OrdenCreateDTO nuevaOrden(LineaOrdenCreateDTO... lineas) {
        return OrdenCreateDTO.builder()
                .email("cliente@email.com")
                .direccionEnvio("Av. Italia 3333, Maldonado")
                .telefono("+59899111222")
                .productos(List.of(lineas))
                .build();
    }

    @Test
    @DisplayName("crearOrden persiste la orden en estado Created y NO descuenta stock (lo hace el procesamiento)")
    void testCrearOrden() {
        when(productoClient.obtenerProducto(1L)).thenReturn(Optional.of(
                ProductoResponse.builder().id(1L).precioUnitario(1250.50).stock(15).build()));
        when(productoClient.obtenerProducto(2L)).thenReturn(Optional.of(
                ProductoResponse.builder().id(2L).precioUnitario(99.90).stock(40).build()));
        when(ordenRepository.save(any(Orden.class))).thenAnswer(inv -> {
            Orden o = inv.getArgument(0);
            o.setId(1001L);
            return o;
        });

        OrdenCreadaDTO creada = ordenService.crearOrden(nuevaOrden(
                LineaOrdenCreateDTO.builder().productoId(1L).cantidad(2).build(),
                LineaOrdenCreateDTO.builder().productoId(2L).cantidad(5).build()));

        assertThat(creada.getId()).isEqualTo(1001L);
        ArgumentCaptor<Orden> guardada = ArgumentCaptor.forClass(Orden.class);
        verify(ordenRepository).save(guardada.capture());
        assertThat(guardada.getValue().getEstado()).isEqualTo(EstadoOrden.Created);
        // Solo consulta los productos; ninguna otra interacción (no modifica stock).
        verify(productoClient, times(2)).obtenerProducto(anyLong());
        verifyNoMoreInteractions(productoClient);
    }

    @Test
    @DisplayName("crearOrden lanza ProductosInexistentesException y no persiste si algún producto no existe")
    void testCrearOrdenProductoInexistente() {
        when(productoClient.obtenerProducto(99L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> ordenService.crearOrden(nuevaOrden(
                LineaOrdenCreateDTO.builder().productoId(99L).cantidad(1).build())))
                .isInstanceOf(ProductosInexistentesException.class)
                .hasMessage("Uno o más productos solicitados no existen");

        verify(ordenRepository, never()).save(any());
    }

    @Test
    @DisplayName("crearOrden lanza StockInsuficienteException y no persiste si falta stock")
    void testCrearOrdenStockInsuficiente() {
        when(productoClient.obtenerProducto(1L)).thenReturn(Optional.of(
                ProductoResponse.builder().id(1L).precioUnitario(1250.50).stock(3).build()));

        assertThatThrownBy(() -> ordenService.crearOrden(nuevaOrden(
                LineaOrdenCreateDTO.builder().productoId(1L).cantidad(5).build())))
                .isInstanceOf(StockInsuficienteException.class)
                .hasMessage("Stock insuficiente para uno o más productos solicitados");

        verify(ordenRepository, never()).save(any());
    }

    private static Orden ordenEn(EstadoOrden estado) {
        return Orden.builder()
                .id(1001L)
                .email("cliente@email.com")
                .direccionEnvio("Av. Italia 3333, Maldonado")
                .telefono("+59899111222")
                .estado(estado)
                .fechaCreacion(OffsetDateTime.parse("2026-06-21T14:30:00-03:00"))
                .build();
    }

    @Test
    @DisplayName("actualizarEstadoProcesamiento pasa una orden Created a Ready to Delivery")
    void testActualizarEstadoAReadyToDelivery() {
        Orden orden = ordenEn(EstadoOrden.Created);
        when(ordenRepository.findById(1001L)).thenReturn(Optional.of(orden));

        ordenService.actualizarEstadoProcesamiento(1001L, EstadoOrden.ReadyToDelivery);

        assertThat(orden.getEstado()).isEqualTo(EstadoOrden.ReadyToDelivery);
        verify(ordenRepository).save(orden);
    }

    @Test
    @DisplayName("actualizarEstadoProcesamiento pasa una orden Created a No Stock")
    void testActualizarEstadoANoStock() {
        Orden orden = ordenEn(EstadoOrden.Created);
        when(ordenRepository.findById(1001L)).thenReturn(Optional.of(orden));

        ordenService.actualizarEstadoProcesamiento(1001L, EstadoOrden.NoStock);

        assertThat(orden.getEstado()).isEqualTo(EstadoOrden.NoStock);
    }

    @Test
    @DisplayName("actualizarEstadoProcesamiento es idempotente si la orden ya tiene ese estado")
    void testActualizarEstadoIdempotente() {
        Orden orden = ordenEn(EstadoOrden.ReadyToDelivery);
        when(ordenRepository.findById(1001L)).thenReturn(Optional.of(orden));

        ordenService.actualizarEstadoProcesamiento(1001L, EstadoOrden.ReadyToDelivery);

        verify(ordenRepository, never()).save(any());
    }

    @Test
    @DisplayName("actualizarEstadoProcesamiento lanza TransicionEstadoInvalidaException si la orden ya fue resuelta de otra forma")
    void testActualizarEstadoTransicionInvalida() {
        when(ordenRepository.findById(1001L)).thenReturn(Optional.of(ordenEn(EstadoOrden.NoStock)));

        assertThatThrownBy(() -> ordenService.actualizarEstadoProcesamiento(1001L, EstadoOrden.ReadyToDelivery))
                .isInstanceOf(TransicionEstadoInvalidaException.class)
                .hasMessage("La orden 1001 no puede pasar de 'No Stock' a 'Ready to Delivery'");
    }

    @Test
    @DisplayName("actualizarEstadoProcesamiento rechaza estados que no son resultado de procesamiento")
    void testActualizarEstadoNoPermitido() {
        assertThatThrownBy(() -> ordenService.actualizarEstadoProcesamiento(1001L, EstadoOrden.Shipped))
                .isInstanceOf(EstadoNoPermitidoException.class);

        verify(ordenRepository, never()).findById(anyLong());
    }

    @Test
    @DisplayName("actualizarEstadoProcesamiento lanza OrdenNoEncontradaException si la orden no existe")
    void testActualizarEstadoOrdenInexistente() {
        when(ordenRepository.findById(9999L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> ordenService.actualizarEstadoProcesamiento(9999L, EstadoOrden.NoStock))
                .isInstanceOf(OrdenNoEncontradaException.class);
    }
}
